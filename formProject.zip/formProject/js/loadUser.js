//load user creates elements for each key/value pair takes obj parameter
const loadUser = function(obj) {
  //loading ele's from dom
  const load = document.getElementById('loadUser');
  const btn = document.getElementById('load');
  const user = document.getElementById('select');

  //creates select options on the fly depending on the amouth of users in the obj
  //and stores the userID in the value attibute for indexing later.
  for (let i = 0; i < obj.length; i++) {
    user.innerHTML += `
      <option value="${obj[i].id}">${obj[i].username}</option>
    `;
  }

  //button click event:
  btn.addEventListener('click', e => {
    e.preventDefault();
    //clears previous loaded user once button is pressed
    load.innerHTML = '';

    //created a var that loops through the obj passed as argument
    //and macthes the id in the obj with the id of the user selected in the dropdown
    //being that the obj is an array (list) i used the {find} method with a callback function {lambda function}
    //which grabs each array elm. by its index and checks the id key/value against the user
    //option value which stores the userID selecleted earlier. this returns the user obj (dictionary) and stores it
    //in the var {loadedUser}
    let loadedUser = obj.find((u, i) => {
      if (obj[i].id == user.value) return u;
    });

    //this loop takes the {loadedUser} obj and loops through each key/value pair
    //then with each loop it creates 3 elms. and div container, then a label with the key as the value
    // and a for attribute that binds it with the input that is created next the name attrubute set to the key
    // and the value set to the value of the key.
    //i created a conditional statment spcific for the  quote field becuase this is an unknown amout of words so i put in
    //into another type of html elm that holds unlimited words.
    for (const key in loadedUser) {
      if (key != 'quote') {
        load.innerHTML += `
        <div>
          <label for="${key}">${key}</label><br>
          <input disabled style=" color: darkred; margin-bottom: 6px;" type="text" name="${key}" value="${loadedUser[key]}" />
        </div>
        `;
      } else {
        load.innerHTML += `
        <div>
          <label for="${key}">${key}</label><br>
          <textarea disabled style=" color: darkred; margin-bottom: 6px;" name="${key}">${loadedUser[key]}</textarea>
        </div>
        `;
      }
    }
  });
};
