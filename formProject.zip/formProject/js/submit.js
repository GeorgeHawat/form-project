// takes the form elemetns and makes a JSON obj
const getValues = function(form) {
  //loading elm's from dom
  const msg = document.getElementById('msg');
  const jsonObj = document.getElementById('json-obj');
  // here i grabbed the form elemtns and stored it in an array called gForms
  const gForm = document.getElementById(form).elements;
  const btn = document.getElementById('submit-btn');

  //btn click event:
  btn.addEventListener('click', e => {
    e.preventDefault();

    //created an empty obj to pass the key values to it in the loop
    const output = {};

    //this loop loops in the gForm array (list)
    for (let i = 0; i < gForm.length; i++) {
      //this checks for elm's with type "checkbox" and gives them a value of false
      if (gForm[i].type === 'checkbox') {
        gForm[i].value = false;
      }

      //this condition checks for check boxes that are checked returns the value of true
      if (gForm[i].checked) {
        gForm[i].value = true;
      }

      //this checks for typs that are not submit to bypass the btn elm,
      //then takse all other elm's and adds key/value pairs in the empty {output} obj
      // useing the name of the elm as the key and the value of the elm as the value.
      if (gForm[i].type !== 'submit') {
        output[gForm[i].name] = gForm[i].value;
      }

      //here i clear the fileds and uncheck all boxes after button is pressed
      gForm[i].value = '';
      gForm[i].checked = false;
    }

    //i insert 2 msgs in the dom one that states "the form was submitted and result is in the console log"
    //and the other inserts the output obj in and converts it to a JSON obj
    msg.innerHTML = 'Form Submitted "check log"';
    jsonObj.innerHTML = JSON.stringify(output);

    //i remove the "form submitted" elm from the dom after 2.5s
    setTimeout(() => {
      msg.innerHTML = '';
    }, 2500);

    // i also post the results in the console log to keep record of each submition.
    console.log(JSON.stringify(output));
  });
};
