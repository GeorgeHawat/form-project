//created a user obj to mimick a json file fetched from a server.
const users = [
  {
    id: 1,
    username: 'gunboss',
    firstName: 'George',
    lastName: 'Hawat',
    hobby: 'guitar',
    quote: 'FOH'
  },
  {
    id: 2,
    username: 'wadman',
    firstName: 'Wadih',
    lastName: 'hawat',
    hobby: 'fix people',
    kids: 3,
    quote: 'khanakhonay'
  },
  {
    id: 3,
    username: 'turboGene',
    firstName: 'joe',
    lastName: 'atalla',
    hobby: 'sex',
    kids: 3,
    quote: 'what your learning now i forgot 20 years ago'
  },
  {
    id: 4,
    username: 'm3allem',
    firstName: 'elie',
    lastName: 'atallah',
    hobby: 'money',
    kids: 1,
    quote: 'I love to yell'
  },
  {
    id: 5,
    username: 'Abou-Wadih',
    firstName: 'Tony',
    lastName: 'Hawat',
    hobby: 'Guns',
    kids: 2,
    quote: 'Best Dad Ever'
  },
  {
    id: 6,
    username: 'GeorgeK',
    firstName: 'George',
    lastName: 'Kaymaz',
    hobby: 'Research',
    quote: 'Your in part of my Comunity'
  }
];
